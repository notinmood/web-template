class TestingController < ApplicationController
  def index
  end

end
