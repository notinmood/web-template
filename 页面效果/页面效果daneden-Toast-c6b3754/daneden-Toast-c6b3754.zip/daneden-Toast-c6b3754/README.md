# Toast Framework
The Toast framework is a super simple toolkit to help rapid design and development. It includes a grid, OOCSS components, typographic baseline and gorgeous form design. Inspired by the likes of Twitter's Bootstrap, the Zerply OOCSS and the 960 grid system.

It's also fully responsive and compatible down to Internet Explorer 7.

To learn more, go to http://daneden.me/toast

## Licence
The styles and code herein are released under http://unlicense.org/.