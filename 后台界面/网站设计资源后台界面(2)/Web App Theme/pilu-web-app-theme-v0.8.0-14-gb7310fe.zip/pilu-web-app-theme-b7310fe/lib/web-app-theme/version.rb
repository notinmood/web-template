module WebAppTheme
  VERSION = '0.8.0'
end
