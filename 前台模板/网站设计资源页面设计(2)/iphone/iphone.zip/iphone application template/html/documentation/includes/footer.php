<hr class="small" />
<div id="footer" class="row">
    <p class="column w1"><?php echo date('Y'); ?> &copy; <strong>Jonnotie</strong></p>
    <p class="column w1">All Rights Reserved</p>
    <p class="column w8">No part of this website may be reproduced, distributed, performed, publicly displayed, or made into a derivative work without the permission of Jonnotie.</p>
</div>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-849980-5");
pageTracker._trackPageview();
} catch(err) {}</script>