require 'web-app-theme/version'

module WebAppTheme
  class Engine < Rails::Engine

  end
end
